function actualizarCantidadProductos(cantidad) {
    var cantidadElemento = document.getElementById("cantidad-productos");
    cantidadElemento.innerHTML = cantidad;
    cantidadElemento.style.display = "block";
    setTimeout(function() {
      cantidadElemento.style.display = "none";
    }, 3000);
}
  
var botonAgregar = document.getElementById("boton-agregar");
var cantidadProductos = 0;
botonAgregar.addEventListener("click", function() {
  cantidadProductos++;
  actualizarCantidadProductos(cantidadProductos);
});
